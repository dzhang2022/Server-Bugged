const express = require("express")
const { process_params } = require("express/lib/router")
const app = express()

const path = require("path");
const { get } = require("express/lib/response");
app.use(express.static(path.join(__dirname, "public")))


app.get("/", function(req, res) {
    res.send(`Welcome to the Site!
    <p><a href = "/contents">Here is a link to the Table of Contents</a></p>
    `)
})

app.get("/contents", function(req, res) {
    res.send(`Welcome to the Table of Contents!
        <p><a href = "/">Return to the home page</a></p>
        <p><a href = "/picture">Would you like a picture?</a></p>
        <p><a href = "/redirect">A cute video?</a></p>
        <p><a href = "/doc">Or just an HTML document?</a></p>
        <p><a href = "/home_formatted">How about better formatting of everything?</a></p>
        `
        + `If you want your name to display, add /{name} to the end of the link!`)
})

app.get("/contents/:name", function(req, res) {
    res.send(`Welcome to the Table of Contents, ` + req.params.name + `!` +
    `<p><a href = "/">Return to the home page</a></p>
    <p><a href = "/picture">Would you like a picture?</a></p>
    <p><a href = "/redirect">A cute video?</a></p>
    <p><a href = "/doc">Or just an HTML document?</a></p>
    <p><a href = "/home_formatted">How about better formatting of everything?</a></p>
    `)
})

app.get("/picture", function(req, res) {
    res.send(`
    <img src="https://careers.nais.org/nsutilities/showLogo.cfm?id=209329&orgType=employer&logoType=Primary" width="400px" height="auto">
    `)
})

app.get("/redirect", function(req, res) {
    res.send(`
    <meta http-equiv="refresh" content="0;URL='https://www.youtube.com/watch?v=W86cTIoMv2U'" /> 
    `)
})

app.get("/doc", function(req, res) {
    res.sendFile("doc.html", { root : "public" })
})

app.get("/contents_formatted/:name", function(req, res) {
    res.sendFile("reformatted.html", { root : "public" })
})

app.get("/home_formatted", function(req, res) {
    res.sendFile("home.html", { root : "public"})
})

app.get("/picture_formatted", function(req, res) {
    res.sendFile("picture.html", { root : "public"})
})

app.get("/redirect_formatted", function(req, res) {
    res.sendFile("redirect.html", { root : "public"})
})

// app.listen(process.env.PORT || 3000); //For pushing to Heroku
app.listen(3000); //For local testing